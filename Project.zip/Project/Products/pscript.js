document.addEventListener("DOMContentLoaded", () => {
  let selectedSize = "";

  function selectSize(size, button) {
    selectedSize = size;
    const buttons = document.querySelectorAll(".size_button button");
    buttons.forEach((btn) => btn.classList.remove("active"));
    button.classList.add("active");
    alert("Selected size: " + selectedSize);
  }

  function addToCart() {
    if (selectedSize === "") {
      alert("Please select a size before adding to the cart.");
      return;
    }
    document.getElementById(
      "cartMessage"
    ).innerHTML = `Added size ${selectedSize} to cart.`;
    alert("Added to cart: Size " + selectedSize);
  }

  const productImage = document.getElementById("productImage");
  const imageModal = document.getElementById("imageModal");
  const modalImage = document.getElementById("modalImage");
  const closeModal = document.getElementById("closeModal");

  productImage.addEventListener("click", () => {
    modalImage.src = productImage.src;
    imageModal.style.display = "flex";
  });

  closeModal.addEventListener("click", () => {
    imageModal.style.display = "none";
  });

  imageModal.addEventListener("click", (e) => {
    if (e.target !== modalImage) {
      imageModal.style.display = "none";
    }
  });

  const sizeButtons = document.querySelectorAll(".size_button button");
  sizeButtons.forEach((button) => {
    button.addEventListener("click", () =>
      selectSize(button.textContent, button)
    );
  });

  const addToCartButton = document.querySelector(".card_button button");
  addToCartButton.addEventListener("click", addToCart);
});
