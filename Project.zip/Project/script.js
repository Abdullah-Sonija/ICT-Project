// search by category
function filterProducts() {
    var category = document.getElementById("categorySelect").value;
    var products = document.querySelectorAll(".s_card");
  
    products.forEach(function (product) {
      if (category === "all") {
        product.style.display = "block";
      } else if (product.classList.contains(category)) {
        product.style.display = "block";
      } else {
        product.style.display = "none";
      }
    });
  }
  